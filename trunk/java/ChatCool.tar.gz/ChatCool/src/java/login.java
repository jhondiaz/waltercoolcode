import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author WalterCool
 * @version 1.0B
 */
public class login extends HttpServlet {
    
     // <editor-fold defaultstate="collapsed" desc="MOST IMPORTANT STATIC variables of all app.">
    public static Hashtable h = new Hashtable();
    public static String user;
    public static Hashtable conectado = new Hashtable();
    // </editor-fold>
     // <editor-fold defaultstate="collapsed" desc="Login Brain.">
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
         // <editor-fold defaultstate="collapsed" desc="Basic Variables and start.">
        response.setContentType("text/html;charset=UTF-8");
        String ip = request.getRemoteAddr();
        HttpSession sesion = request.getSession(true);
        PrintWriter out = response.getWriter();
        user = new String(request.getParameter("login"));
        String pass = new String(request.getParameter("pass"));
        out.println("<html>");
        out.println("<head>");
        out.println("</head>");
        out.println("<body>");
        // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Anti-bugs of multi-login.">
        if (conectado.get(ip) != null)
        {
            out.println("You have a old session, u need disconect it before login again");
            out.println("<form action=chat method=post>");
            out.println("<input type=submit value=Continue /></form>");
            out.println("</body>");
            out.println("</html>");
            out.close();
        }
         // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Auto-create user if doesn't exist a user.">
        if (h.isEmpty())
        {
            h.put(user, pass);
            out.println("<center>Your user doesn't exist, is created now with this details:<br />");
            out.println("Username: " + user + "<br />");
            out.print("Password: ");
            for (int x=0;x<pass.length();x++)
            {
                out.print("*");
            }
            out.println("<br /><br /><br />Please come back and enter again</center>");
        }
        // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="If exist....">
        else
        {
            String a = (String)h.get(user);
             // <editor-fold defaultstate="collapsed" desc="Create a user if exist at least a user.">
            if (a == null)
            {
                h.put(user, pass);
                out.println("<center>Your user doesn't exist, is created now with this details:");
                out.println("Username: " + user);
                out.print("Password: ");
                for (int x=0;x<pass.length();x++)
                {
                    out.print("*");
                }
                out.println("<br /><br /><br />Please come back and enter again</center>");
            }
             // </editor-fold>
             // <editor-fold defaultstate="collapsed" desc="If password is OK, enter please.">
            else if  (a.equals(pass))
            {
                out.println("<center>Welcome to chat " + user + "<br />");
                out.println("For enter in the main menu, make clic in enter");
                out.println("<form action= chat method=post>");
                out.println("<input type=submit value=Enter />");
                out.println("</form></center>");
                conectado.put(ip,user);
            }
             // </editor-fold>
             // <editor-fold defaultstate="collapsed" desc="If not, try again.">
            else
            {
                out.println("Error in login, try again please");
            }
             // </editor-fold>
        }
         // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Basic end.">
        out.println("");
        out.println("</body>");
        out.println("</html>");
        out.close();
         // </editor-fold>
    }
     // </editor-fold>
    
    
     // <editor-fold defaultstate="collapsed" desc="Stupid Additions of Netbeans, but seems cool.">

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    // </editor-fold>
}
