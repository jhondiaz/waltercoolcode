import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author WalterCool
 * @version 1.0B
 */

public class chat extends HttpServlet 
{
     // <editor-fold defaultstate="collapsed" desc="Public static vars.">
    static Cookie[] cookies;
    public static int nn=1;
    // </editor-fold>
     // <editor-fold defaultstate="collapsed" desc="DoPost (Main Interfase).">
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
         // <editor-fold defaultstate="collapsed" desc="Start with basics.">
        PrintWriter out = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        cookies = request.getCookies();
        String ip = request.getRemoteAddr();
        String user = (String)login.conectado.get(ip);
         // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Anti-badcode.">
        if (user == null)
        {
            out.println("U cant stay here!!!!");
            out.println("GO TO START!");
            out.println("<form action=index.jsp><input type=submit value=START! /></form>");
            out.close();
        }
        // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="HTML BASE.">
        out.println("<html>");
        out.println("<head>");
        out.println("<title>ChatCool</title>");
        out.println("</head>");
        out.println("<body>");
        //</editor-fold>
         // <editor-fold defaultstate="collapsed" desc="All about BKcolor.">
        String color = request.getParameter("color");
        if (color==null)
        {
            Cookie colorBK = new Cookie("color","white");
            response.addCookie(colorBK);
            out.println("<body bgcolor=white>");
        }
        else
        {
            Cookie colorBK = new Cookie("color",color);
            response.addCookie(colorBK);
            out.println("<body bgcolor="+ color + ">");
        }
        // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Logout method.">
        out.println("<center><b2>WalterCool Chat</b2><form action=logout method=get>" +
                "<input type=submit value=Logout /></form");
         // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Chat enviroment.">
        out.println("<textarea rows='20' cols='50'>");
        for(int x=1;x<cookies.length;x++)
        {
            if (cookies[x].getName().equals("color") == false)
            {
                out.println(cookies[x].getName() + ": " + cookies[x].getValue());
            }
        }
        out.println("</textarea>");
         // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="User Enviroment.">
        out.println("<textarea rows='20' cols='20'>");
        Enumeration e = login.conectado.elements(); 
        while (e.hasMoreElements())
        {
            out.println ((String)e.nextElement());
        }
        out.println("</textarea><br />");
         // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="End and redirect to post in chat (get method).">
        out.println("<form action=chat method=get>");
        out.println("<input type='text' name='message' />");
        out.println("<input type=submit value=Send />");
        out.println("</form>");
        out.println("</center></body>");
        out.println("</html>");
        out.close();
         // </editor-fold>
    }
     // </editor-fold>
     // <editor-fold defaultstate="collapsed" desc="DoGet (Posts and Color).">
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
         // <editor-fold defaultstate="collapsed" desc="Variables.">
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String message = request.getParameter("message");
        String ip = request.getRemoteAddr();
        cookies = request.getCookies();
        String user = (String)login.conectado.get(ip);
        String colorBK="";
        // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Search for cookies with color related.">
        for(int x=0;x<cookies.length;x++)
        {
            if (cookies[x].getName().equals("color"))
            {
                colorBK=cookies[x].getValue();
            }
        }
        // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Make a post in cookie.">
        Cookie cookie = new Cookie( ""+nn + ".-" + user, message);
        response.addCookie(cookie);
        nn++;
        // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="HTML Print of doGet.">
        out.println("Message Sent, For Back, Please Make Clic In Back Button<br />");
        out.println("<form action=chat method=post>");
        out.println("Current color: <input type=text name=color value=" + colorBK + " />");
        out.println("<input type=submit value=Back>");
        out.println("</form>");
        //</editor-fold>
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Stupid Additions Of Netbeans.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doPost(request, response);
    }
    
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
