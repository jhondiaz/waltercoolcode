import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author WalterCool
 * @version 1.0B
 */

public class logout extends HttpServlet 
{
    
        // <editor-fold defaultstate="collapsed" desc="DoGet (Logout).">
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
         // <editor-fold defaultstate="collapsed" desc="Basics.">
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String ip = request.getRemoteAddr();
         // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Anti-bugs.">
        if(login.conectado.get(ip) == null)
        {
            out.println("How u get here?? Start of the START!!");
            out.println("<form action=index.jsp><input type=submit value=START! /></form>");
            out.close();
        }
        // </editor-fold>
         // <editor-fold defaultstate="collapsed" desc="Disconnect Function.">
        login.conectado.remove(ip);
        out.println("You have been disconected correctly");
        out.close();
        // </editor-fold>
    }
        // </editor-fold>
    
        // <editor-fold defaultstate="collapsed" desc="DoPost.">
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
        
    }
    // </editor-fold>
}
